message = "Hi I am James"
print(message)


message = "Hi there Python World! I am James"
print(message)