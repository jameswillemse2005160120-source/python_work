first_name = "ada"
last_name = "lovelace"
#f-strings: allow fotr foramting of strings
