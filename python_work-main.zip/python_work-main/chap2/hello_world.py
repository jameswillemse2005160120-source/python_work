# Assign a message to the variable
message = "Hello Python world!"

# Print the first message
print(message)

# Add a blank line for clarity (optional in code, but helps visually)
print()  # This prints an empty line

# Change the value of the variable
message = "Hello Python Crash Course world!"

# Print the updated message
print(message)