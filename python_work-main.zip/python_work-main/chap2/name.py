# Assign a lowercase name to the variable
name = "ada lovelace"

# Print the name in title case (each word capitalized)
print(name.title())  # Output: Ada Lovelace

# Print the name in uppercase
print(name.upper())  # Output: ADA LOVELACE

# Print the name in lowercase
print(name.lower())  # Output: ada lovelacek sall