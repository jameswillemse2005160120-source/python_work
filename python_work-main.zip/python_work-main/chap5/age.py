 age = 18
 age == 18
True