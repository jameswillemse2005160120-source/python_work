alien_0 = {'color': 'green' ,'speed':'slow'}

print(alien_0['points'] )

point_value = alien_0.get
print(alien_0)