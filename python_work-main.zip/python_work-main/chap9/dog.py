class Dog:
 """A simple attempt to model a dog."""
 def __init__(self, name, age):
         """Initialize name and age attributes."""
self.name = name
self.age = age

def sit(self):
      """Simulate a dog sitting in response to a command."""
      print(f"{self.name} is now sitting.")

def roll_over(self):
     """Simulate rolling over in response to a command."""
     print(f"{self.name} rolled over!")

my_dog = Dog('willie', 6)
your_dog = Dog('Lucy', 3)

print(f"your dog is {my_dog_.name}.")
print(f"your dog is {my_dog_.age}years old.")


print(f"\nyour dog's name is {your_dog_.name}.")
print(f"your dog is {your_dog_.age}years old.")
your_dog.sit()